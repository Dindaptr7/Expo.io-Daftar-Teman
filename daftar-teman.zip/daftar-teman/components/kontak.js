import React from 'react';
import {View,Text,Image,StyleSheet,Button} from 'react-native';

export default function Contact(props) {
  return(
    <View style={styles.container}>
      <Image source={props.gambar} style={styles.img} />
    <View style={styles.teks}>
      <Text style={styles.title}>{props.judul} </Text>
      <Text style={styles.telp}>{props.telpon} </Text>
    </View>
    </View>
  )
}

const styles =StyleSheet.create({

  container:{
    height:100,
    flexDirection:'row',
    alignItems:'center',
    borderBottomWidth:1,
    borderColor:'Pink',
    color :'Pink'
  },
  img:{
    margin:10,
    width:70,
    height:70
  },
  teks:{flex:1},

  title:{
    fontWeight:'bold',
    fontSize:16,
    color: '#DCA18F'
  },
  telp:{
    fontSize:14,
    color:'#DCA18F'
  }
})