import React from 'react'
import {Text, View, StyleSheet, Button} from 'react-native';

import Contact from './kontak';

  const About = ({navigation}) => {
  return(
    <View>
    <Contact
      gambar={require("./nana.jpg")}
      judul="Raina Rahmawati Fitri"
      telpon="089523915062"/>

    <Contact
      gambar={require("./sarah.jpg")}
      judul="Sarah Syakira Rambe"
      telpon="085872322510"/>

    <Contact
      gambar={require("./jijeh.jpg")}
      judul="Siti Nur Azizah"
      telpon="085892501680"/>
      
    <Contact
      gambar={require("./ruhu.jpg")}
      judul="Siti Ruhu Salamah"
      telpon="085864503792"/>

      <Button title="More" onPress={()=> navigation.goBack()}/>
    </View>
  )
}

export default About;