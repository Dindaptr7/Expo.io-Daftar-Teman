import React from 'react'
import {Text, View, StyleSheet, Button} from 'react-native'

const Home=({navigation}) => {
  return(
    <View>
      <Text>Daftar Teman</Text>
      <Button title ='Teman'
      onPress={() => navigation.navigate ('About')} />
      </View>
  )
}
export default Home;